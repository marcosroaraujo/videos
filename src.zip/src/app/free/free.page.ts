import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-free',
  templateUrl: './free.page.html',
  styleUrls: ['./free.page.scss'],
})
export class FreePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
