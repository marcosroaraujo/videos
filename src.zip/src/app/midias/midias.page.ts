import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-midias',
  templateUrl: './midias.page.html',
  styleUrls: ['./midias.page.scss'],
})
export class MidiasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
